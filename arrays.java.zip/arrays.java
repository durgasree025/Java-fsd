public class arrays {
    public static void main(String[] args) {
        // Example 1: Storing student names in an array
        String[] studentNames = {"Durga", "Abc", "Sophia", "Mani"};

        System.out.println("Number of students: " + studentNames.length);
        System.out.println("First student: " + studentNames[0]);
        System.out.println("Last student: " + studentNames[studentNames.length - 1]);

        // Example 2: Storing marks in an array
        double[] marks = {25.5, 28.3, 30.2, 27.8, 26.1};

        System.out.println("Number of total marks readings: " + marks.length);
        System.out.println("Marks in 3rd list: " + marks[2]);
        System.out.println("Average of total marks: " + calculateAverage(marks));
    }

    public static double calculateAverage(double[] values) {
        double sum = 0;
        for (double value : values) {
            sum += value;
        }
        return sum / values.length;
    }
}
