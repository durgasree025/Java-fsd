public class innerClasses {
    private String outerVariable = "Outer";

    public void outerMethod() {
        System.out.println("Outer method");
    }

    public class InnerClass {
        public void innerMethod() {
            System.out.println("Inner method");
        }

        public void accessOuter() {
            System.out.println("Accessing outer variable: " + outerVariable);
            outerMethod();
        }
    }

    public static void main(String[] args) {
        innerClasses outerObj = new innerClasses();
        innerClasses.InnerClass innerObj = outerObj.new InnerClass();

        innerObj.innerMethod();
        innerObj.accessOuter();
    }
}
