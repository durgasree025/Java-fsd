public class accessModifiers {
    public static void main(String[] args) {
        // Create an instance of the Car class
        Car myCar = new Car();

        // Access public members
        myCar.startEngine();
        System.out.println(myCar.brand);

        // Access default (package-private) members
        myCar.drive();
        System.out.println(myCar.model);
    }
}

class Car {
    public String brand = "Tesla";
    String model = "Model 3";

    public void startEngine() {
        System.out.println("Engine started");
    }

    void drive() {
        System.out.println("Car is being driven");
    }
}
