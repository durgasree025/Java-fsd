import java.util.HashMap;
import java.util.Map;

public class hashmap {
    public static void main(String[] args) {
        // Storing employee information using a HashMap
        Map<String, String> employeeInfo = new HashMap<>();
        employeeInfo.put("Mani", "Manager");
        employeeInfo.put("Durga", "Engineer");
        employeeInfo.put("Sophia", "Analyst");

        System.out.println("Example: Storing employee information using a HashMap");
        System.out.println("Number of employees: " + employeeInfo.size());
        System.out.println("John's designation: " + employeeInfo.get("Mani"));
        System.out.println("Emily's designation: " + employeeInfo.get("Sophia"));
    }
}
