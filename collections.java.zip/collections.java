import java.util.*;

public class collections {
    public static void main(String[] args) {
        // Example 1: Storing a list of names in an ArrayList
        List<String> names = Arrays.asList("Durga", "Mani", "Vikram", "Sophia");

        System.out.println("Storing a list of names in an ArrayList");
        System.out.println("No of names: " + names.size());
        System.out.println("Names: " + names);

        // Example 2: Storing key-value pairs in a HashMap
        Map<String, Integer> scores = new HashMap<>();
        scores.put("Durga", 90);
        scores.put("Mani", 85);
        scores.put("Vikram", 95);
        scores.put("Sophia", 92);

        System.out.println("Storing key-value pairs in a HashMap");
        System.out.println("No of scores: " + scores.size());
        System.out.println(" Total Scores: " + scores);
    }
}
