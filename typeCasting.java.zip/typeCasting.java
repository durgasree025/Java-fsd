public class typeCasting {
    public static void main(String[] args) {
        // Implicit Type Casting
        int boxWeight = 10;
        double totalWeight = boxWeight;

        System.out.println("Implicit Type Casting:");
        System.out.println(" Box weight" + boxWeight);
        System.out.println("totalWeight (double): " + totalWeight);

        // Explicit Type Casting
        double totalPrice = 15.75;
        int roundedPrice = (int) totalPrice;

        System.out.println("\nExplicit Type Casting:");
        System.out.println("totalPrice (double): " + totalPrice);
        System.out.println("roundedPrice (int): " + roundedPrice);
    }
}
